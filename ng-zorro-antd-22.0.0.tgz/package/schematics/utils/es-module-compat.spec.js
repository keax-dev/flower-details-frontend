"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const module_1 = require("module");
const path_1 = require("path");
describe('schematics es module compatibility', () => {
    it('should ship a commonjs package.json in schematics', () => {
        const packageJsonPath = (0, path_1.join)(__dirname, '../package.json');
        expect((0, fs_1.existsSync)(packageJsonPath)).toBe(true);
        expect(JSON.parse((0, fs_1.readFileSync)(packageJsonPath, 'utf8'))).toEqual({ type: 'commonjs' });
    });
    it('should load migrations when the library root package uses type module', () => {
        const schematicsDir = (0, path_1.join)(__dirname, '..');
        const rootDir = (0, path_1.join)(schematicsDir, '..');
        const rootPackageJson = (0, path_1.join)(rootDir, 'package.json');
        const hadRootPackageJson = (0, fs_1.existsSync)(rootPackageJson);
        const originalContent = hadRootPackageJson ? (0, fs_1.readFileSync)(rootPackageJson, 'utf8') : undefined;
        try {
            (0, fs_1.writeFileSync)(rootPackageJson, JSON.stringify({ name: 'ng-zorro-antd', type: 'module' }));
            const requireFromRoot = (0, module_1.createRequire)(rootPackageJson);
            const migration = requireFromRoot('./schematics/ng-update/index.js');
            expect(typeof migration.updateToV22).toBe('function');
            expect(typeof migration.postUpdate).toBe('function');
        }
        finally {
            if (hadRootPackageJson && originalContent !== undefined) {
                (0, fs_1.writeFileSync)(rootPackageJson, originalContent);
            }
            else {
                (0, fs_1.rmSync)(rootPackageJson, { force: true });
            }
        }
    });
});
//# sourceMappingURL=es-module-compat.spec.js.map