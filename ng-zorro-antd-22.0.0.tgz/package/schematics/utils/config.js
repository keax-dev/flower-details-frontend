"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefaultComponentOptions = getDefaultComponentOptions;
exports.getAppOptions = getAppOptions;
const config_1 = require("@angular/cli/src/utilities/config");
const core_1 = require("@angular-devkit/core");
/**
 * Returns the default options for the `@schematics/angular:component` schematic which would
 * have been specified at project initialization (ng new or ng init).
 */
function getDefaultComponentOptions(project) {
    return __awaiter(this, void 0, void 0, function* () {
        return (0, config_1.getSchematicDefaults)('@schematics/angular', 'component', project);
    });
}
function getAppOptions(project, projectRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const componentOptions = yield getDefaultComponentOptions(project);
        (_a = componentOptions.type) !== null && _a !== void 0 ? _a : (componentOptions.type = '');
        const appDir = (0, core_1.normalize)(projectRoot);
        const sourceDir = `${appDir}/src/app`;
        return {
            componentOptions,
            sourceDir
        };
    });
}
//# sourceMappingURL=config.js.map