"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addDateAdapterProvider = addDateAdapterProvider;
const schematics_1 = require("@angular-devkit/schematics");
const utility_1 = require("@schematics/angular/utility");
function addDateAdapterProvider(options) {
    const dateAdapter = options.dateAdapter || 'date-fns';
    if (dateAdapter === 'none') {
        return (0, schematics_1.noop)();
    }
    return (0, utility_1.addRootProvider)(options.project, ({ code, external }) => {
        if (dateAdapter === 'native') {
            return code `${external('provideNzNativeDateAdapter', 'ng-zorro-antd/core/time')}()`;
        }
        else {
            // date-fns
            return code `${external('provideNzDateFnsAdapter', 'ng-zorro-antd/core/time')}()`;
        }
    });
}
//# sourceMappingURL=date-adapter.js.map