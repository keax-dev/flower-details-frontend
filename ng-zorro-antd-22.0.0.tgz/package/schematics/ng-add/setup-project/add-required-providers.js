"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addRequiredProviders = addRequiredProviders;
const schematics_1 = require("@angular-devkit/schematics");
const utility_1 = require("@schematics/angular/utility");
function addRequiredProviders(options) {
    return (0, schematics_1.chain)([
        addAnimations(options)
    ]);
}
function addAnimations(options) {
    if (options.animations) {
        return (0, schematics_1.noop)();
    }
    return (0, utility_1.addRootProvider)(options.project, ({ code, external }) => {
        return code `${external('provideNzNoAnimation', 'ng-zorro-antd/core/animation')}()`;
    });
}
//# sourceMappingURL=add-required-providers.js.map