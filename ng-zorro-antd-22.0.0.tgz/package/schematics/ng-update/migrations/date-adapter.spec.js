"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const schematics_1 = require("@angular/cdk/schematics");
const rxjs_1 = require("rxjs");
const testing_1 = require("@angular-devkit/schematics/testing");
const date_adapter_1 = require("./date-adapter");
const test_app_1 = require("../../testing/test-app");
const get_file_content_1 = require("../../utils/get-file-content");
const upgrade_data_1 = require("../upgrade-data");
describe('date adapter migration', () => {
    let runner;
    beforeEach(() => {
        runner = new testing_1.SchematicTestRunner('schematics', require.resolve('../../collection.json'));
    });
    it('should add provideNzDateFnsAdapter to standalone app config providers', () => __awaiter(void 0, void 0, void 0, function* () {
        const tree = yield runDateAdapterMigration(yield (0, test_app_1.createTestApp)(runner));
        const appConfig = (0, get_file_content_1.getFileContent)(tree, '/projects/ng-zorro/src/app/app.config.ts');
        expect(appConfig).toContain(`import { provideNzDateFnsAdapter } from 'ng-zorro-antd/core/time';`);
        expect(appConfig).toContain('provideNzDateFnsAdapter()');
    }));
    it('should not add provideNzDateFnsAdapter twice', () => __awaiter(void 0, void 0, void 0, function* () {
        const appTree = yield (0, test_app_1.createTestApp)(runner);
        const content = `${(0, get_file_content_1.getFileContent)(appTree, '/projects/ng-zorro/src/app/app.config.ts').replace('providers: [', `providers: [provideNzDateFnsAdapter(), `)}\nimport { provideNzDateFnsAdapter } from 'ng-zorro-antd/core/time';\n`;
        appTree.overwrite('/projects/ng-zorro/src/app/app.config.ts', content);
        const tree = yield runDateAdapterMigration(appTree);
        const appConfig = (0, get_file_content_1.getFileContent)(tree, '/projects/ng-zorro/src/app/app.config.ts');
        expect(countMatches(appConfig, 'provideNzDateFnsAdapter()')).toBe(1);
    }));
    it('should not override an explicit native date adapter provider', () => __awaiter(void 0, void 0, void 0, function* () {
        const appTree = yield (0, test_app_1.createTestApp)(runner);
        const content = `${(0, get_file_content_1.getFileContent)(appTree, '/projects/ng-zorro/src/app/app.config.ts').replace('providers: [', `providers: [provideNzNativeDateAdapter(), `)}\nimport { provideNzNativeDateAdapter } from 'ng-zorro-antd/core/time';\n`;
        appTree.overwrite('/projects/ng-zorro/src/app/app.config.ts', content);
        const tree = yield runDateAdapterMigration(appTree);
        const appConfig = (0, get_file_content_1.getFileContent)(tree, '/projects/ng-zorro/src/app/app.config.ts');
        expect(appConfig).toContain('provideNzNativeDateAdapter()');
        expect(appConfig).not.toContain('provideNzDateFnsAdapter()');
    }));
    it('should add provideNzDateFnsAdapter to NgModule providers', () => __awaiter(void 0, void 0, void 0, function* () {
        const tree = yield runDateAdapterMigration(yield (0, test_app_1.createTestApp)(runner, { standalone: false }));
        const appModule = (0, get_file_content_1.getFileContent)(tree, '/projects/ng-zorro/src/app/app-module.ts');
        expect(appModule).toContain(`import { provideNzDateFnsAdapter } from 'ng-zorro-antd/core/time';`);
        expect(appModule).toContain('provideNzDateFnsAdapter()');
    }));
    function runDateAdapterMigration(tree) {
        return __awaiter(this, void 0, void 0, function* () {
            const rule = (0, schematics_1.createMigrationSchematicRule)(schematics_1.TargetVersion.V22, [date_adapter_1.DateAdapterMigration], upgrade_data_1.nzUpgradeData);
            return (0, rxjs_1.lastValueFrom)(runner.callRule(rule, tree));
        });
    }
    function countMatches(value, pattern) {
        return value.split(pattern).length - 1;
    }
});
//# sourceMappingURL=date-adapter.spec.js.map