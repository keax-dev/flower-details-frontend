"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImportSpecifiersMigration = void 0;
const schematics_1 = require("@angular/cdk/schematics");
const ts = __importStar(require("typescript"));
const module_specifiers_1 = require("../../utils/ng-update/module-specifiers");
const upgrade_data_1 = require("../upgrade-data");
class ImportSpecifiersMigration extends schematics_1.Migration {
    constructor() {
        super(...arguments);
        /** Change data that upgrades to the specified target version. */
        this.data = (0, upgrade_data_1.getVersionUpgradeData)(this, 'importSpecifiers');
        // Only enable the migration rule if there is upgrade data.
        this.enabled = this.data.length !== 0;
    }
    visitNode(node) {
        if (ts.isImportDeclaration(node)) {
            this.visitImportDeclaration(node);
        }
    }
    visitImportDeclaration(node) {
        if ((0, module_specifiers_1.isNgZorroImportDeclaration)(node)) {
            return this._createFailureWithReplacement(node);
        }
    }
    /** Creates a failure and replacement for the specified identifier. */
    _createFailureWithReplacement(identifier) {
        const upgradeData = this.data.find(({ replace }) => identifier.moduleSpecifier.getText().indexOf(replace) !== -1);
        if (upgradeData) {
            const filePath = this.fileSystem.resolve(identifier.getSourceFile().fileName);
            this.fileSystem.edit(filePath)
                .remove(identifier.moduleSpecifier.getStart() + 1, identifier.moduleSpecifier.getWidth() - 2) // quotes
                .insertRight(identifier.moduleSpecifier.getStart() + 1, upgradeData.replaceWith);
        }
    }
}
exports.ImportSpecifiersMigration = ImportSpecifiersMigration;
//# sourceMappingURL=import-specifiers.js.map