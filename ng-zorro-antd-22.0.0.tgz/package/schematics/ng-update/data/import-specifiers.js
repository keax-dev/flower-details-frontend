"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.importSpecifiers = void 0;
const schematics_1 = require("@angular/cdk/schematics");
const resolve = (module) => `ng-zorro-antd/${module}`;
exports.importSpecifiers = {
    [schematics_1.TargetVersion.V22]: [
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9528',
            changes: [
                {
                    replace: resolve('water-mark'),
                    replaceWith: resolve('watermark')
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9555',
            changes: [
                {
                    replace: resolve('core/no-animation'),
                    replaceWith: resolve('core/animation')
                }
            ]
        }
    ]
};
//# sourceMappingURL=import-specifiers.js.map