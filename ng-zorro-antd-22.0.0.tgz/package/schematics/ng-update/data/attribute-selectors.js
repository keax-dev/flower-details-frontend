"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.attributeSelectors = void 0;
const schematics_1 = require("@angular/cdk/schematics");
exports.attributeSelectors = {
    [schematics_1.TargetVersion.V22]: []
};
//# sourceMappingURL=attribute-selectors.js.map