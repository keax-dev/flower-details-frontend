"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.classNames = void 0;
const schematics_1 = require("@angular/cdk/schematics");
exports.classNames = {
    [schematics_1.TargetVersion.V22]: [
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9238',
            changes: [
                {
                    replace: 'NzTabsetComponent',
                    replaceWith: 'NzTabsComponent'
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9285',
            changes: [
                {
                    replace: 'NzToolTipComponent',
                    replaceWith: 'NzTooltipComponent'
                },
                {
                    replace: 'NzToolTipModule',
                    replaceWith: 'NzTooltipModule'
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9330',
            changes: [
                {
                    replace: 'NzStatisticNumberComponent',
                    replaceWith: 'NzStatisticContentValueComponent'
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9527',
            changes: [
                {
                    replace: 'NzDropDownModule',
                    replaceWith: 'NzDropdownModule'
                },
                {
                    replace: 'NzDropDownADirective',
                    replaceWith: 'NzDropdownADirective'
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9528',
            changes: [
                {
                    replace: 'NzWaterMarkModule',
                    replaceWith: 'NzWatermarkModule'
                },
                {
                    replace: 'NzWaterMarkComponent',
                    replaceWith: 'NzWatermarkComponent'
                }
            ]
        }
    ]
};
//# sourceMappingURL=class-names.js.map