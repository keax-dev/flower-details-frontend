"use strict";
/**
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://github.com/NG-ZORRO/ng-zorro-antd/blob/master/LICENSE
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.elementSelectors = void 0;
const schematics_1 = require("@angular/cdk/schematics");
exports.elementSelectors = {
    [schematics_1.TargetVersion.V22]: [
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9238',
            changes: [
                {
                    replace: 'nz-tabset',
                    replaceWith: 'nz-tabs'
                }
            ]
        },
        {
            pr: 'https://github.com/NG-ZORRO/ng-zorro-antd/pull/9330',
            changes: [
                {
                    replace: 'nz-statistic-number',
                    replaceWith: 'nz-statistic-content-value'
                }
            ]
        }
    ]
};
//# sourceMappingURL=element-selectors.js.map